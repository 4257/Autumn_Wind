package com.itheima;

import org.junit.Test;

public class TestMaven {
    @Test
    public void test(){
        System.out.println("maven test ====>");
    }
}
